# Public Health Analytics & Predictive Modeling

This project analyzes water quality data to build predictive models for public health insights.

## Structure
- `scripts/`: Python scripts for preprocessing, modeling, and evaluation
- `data/`: Sample dataset placeholder
- `outputs/`: Folders for figures and model files

## Tools Used
- Python, Pandas, Scikit-learn, Matplotlib

## Author
Sudheestna Penumarthi