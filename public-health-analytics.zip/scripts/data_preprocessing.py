# Preprocessing script

print('Preprocessing data...')