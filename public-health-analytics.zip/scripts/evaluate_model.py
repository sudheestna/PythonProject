# Model evaluation script

print('Evaluating model...')