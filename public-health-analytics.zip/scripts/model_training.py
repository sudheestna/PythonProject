# Model training script

print('Training model...')